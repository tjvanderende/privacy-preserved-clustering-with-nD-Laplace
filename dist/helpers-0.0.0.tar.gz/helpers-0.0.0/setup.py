from setuptools import setup, find_packages

setup(name='helpers', packages=find_packages(where='./Helpers'))